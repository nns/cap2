

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

public class Cap {
	
    private static final String POST_METHOD = "POST"; 
    private static final String CONNECTION = "Connection";
    private static final String CHARSET = "Charset";
    private static final String CONTENT_TYPE = "Content-Type";
    
    private static final String KEEP_ALIVE = "Keep-Alive";
    private static final String UTF8 = "UTF-8";
    private static final String MULTIPART_BOUNDARY = "multipart/form-data; boundary=";
    private static final String prfx_boundary = "-----------------------------";
    
    private static final String FORM_LBL_USRFILE = "userfile";
    
    private static final String twohyphens = "--";
    private static final String end = "\r\n";
    private static final String dq = "\"";

    
    private static String mBoundary;
    
    private static final String ext = "jpg";
    
    private static String address;
    private static String userName;
    private static int timer;
    private static float compless;
	/**
	 * @param args
	 * @throws Throwable 
	 */
    public static void main(String[] args) throws Throwable {
    	address = args[0];
    	timer = Integer.parseInt(args[1]);
    	compless = Float.parseFloat(args[2]);
    	userName = args[3];
    	System.out.println(address);
    	System.out.println(userName);
    	
    	//���O�̏d���`�F�b�N���Ȃ���
    	
    	
    	Robot rb = new Robot();
    	//�L���v�`�����s
    	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    	Rectangle r = new Rectangle(screenSize);
    	ByteArrayOutputStream out = new ByteArrayOutputStream();
    	URL url = new URL(address);
    	Iterator<ImageWriter> it = ImageIO.getImageWritersByFormatName(ext);
    	ImageWriter writer = it.next();
    	//���[�v
    	while(true){
    		try{
    			BufferedImage img = rb.createScreenCapture(r);
    			ImageOutputStream stream = ImageIO.createImageOutputStream(out);
    			writer.setOutput(stream);
    			ImageWriteParam param = writer.getDefaultWriteParam();
    			param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
    			param.setCompressionQuality(compless);
    			writer.write(null, new IIOImage(img, null, null), param);
    			
    			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
    			conn.setDoOutput(true);
    			conn.setDoInput(true);
    			conn.setUseCaches(false);
    			
    			
    			mBoundary = prfx_boundary + Long.toString(System.currentTimeMillis());
    			// �w�b�_�ݒ�
    			conn.setRequestMethod(POST_METHOD);
    			conn.setRequestProperty(CONNECTION, KEEP_ALIVE);
    			conn.setRequestProperty(CHARSET, UTF8);
    			conn.setRequestProperty(CONTENT_TYPE, MULTIPART_BOUNDARY + mBoundary);
    			conn.setDoOutput(true);
    			conn.setUseCaches(false);
    			
    			// �w�b�_�ݒ�
    			conn.setRequestMethod(POST_METHOD);
    			conn.setRequestProperty(CONNECTION, KEEP_ALIVE);
    			conn.setRequestProperty(CHARSET, UTF8);
    			conn.setRequestProperty(CONTENT_TYPE, MULTIPART_BOUNDARY + mBoundary);
    			
    			// ���M�f�[�^�̐ݒ�
    			DataOutputStream os = new DataOutputStream(conn.getOutputStream());
    			append_pgmfile(os, FORM_LBL_USRFILE, userName, out.toByteArray());
    			append_final(os);
    			os.flush();
    			os.close();
    			out = new ByteArrayOutputStream();
    			// ���ʎ󂯎��
    			final int responceCode = conn.getResponseCode();
    			System.out.println(responceCode);
    			Thread.sleep(timer);
    		}catch(Exception e){
    			e.printStackTrace();
    			Thread.sleep(5000);
    		}
    	}
    }
	private static void  append_pgmfile(DataOutputStream os, String name, String filename, byte[] b) throws IOException {
		os.writeBytes(twohyphens + mBoundary + end);
		os.writeBytes("Content-Disposition: form-data; name=" + dq + name + dq + "; filename=" + dq + filename + dq + end);
		os.writeBytes("Content-Type: application/octet-stream" + end + end);
		os.write(b);
		os.writeBytes(end);		
	}
	
	private static void append_final(DataOutputStream os) throws IOException {
		os.writeBytes(twohyphens + mBoundary + twohyphens + end);
	}

}
